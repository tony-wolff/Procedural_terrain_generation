#ifdef WIN32
/* windows stuff */
#else
typedef signed long long LONG;
typedef unsigned long DWORD;
typedef unsigned short WORD;
typedef unsigned int UNINT32;
#endif